CREATE DEFINER = kai@localhost TRIGGER trg_catalog_product_entity_int_after_insert
    AFTER INSERT
    ON catalog_product_entity_int
    FOR EACH ROW
BEGIN
INSERT IGNORE INTO `scconnector_google_feed_cl` (`entity_id`) VALUES (NEW.`entity_id`);
INSERT IGNORE INTO `scconnector_google_remove_cl` (`entity_id`) VALUES (NEW.`entity_id`);
END;


CREATE DEFINER = kai@localhost TRIGGER trg_catalog_product_website_after_insert
    AFTER INSERT
    ON catalog_product_website
    FOR EACH ROW
BEGIN
INSERT IGNORE INTO `scconnector_google_remove_cl` (`entity_id`) VALUES (NEW.`product_id`);
END;


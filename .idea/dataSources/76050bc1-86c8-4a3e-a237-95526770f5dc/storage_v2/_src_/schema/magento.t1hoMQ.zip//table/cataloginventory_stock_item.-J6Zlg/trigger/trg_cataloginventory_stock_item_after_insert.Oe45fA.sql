CREATE DEFINER = kai@localhost TRIGGER trg_cataloginventory_stock_item_after_insert
    AFTER INSERT
    ON cataloginventory_stock_item
    FOR EACH ROW
BEGIN
INSERT IGNORE INTO `scconnector_google_feed_cl` (`entity_id`) VALUES (NEW.`product_id`);
END;


CREATE DEFINER = kai@localhost TRIGGER trg_catalog_product_entity_after_update
    AFTER UPDATE
    ON catalog_product_entity
    FOR EACH ROW
BEGIN
IF (NEW.`entity_id` <=> OLD.`entity_id` OR NEW.`attribute_set_id` <=> OLD.`attribute_set_id` OR NEW.`type_id` <=> OLD.`type_id` OR NEW.`sku` <=> OLD.`sku` OR NEW.`has_options` <=> OLD.`has_options` OR NEW.`required_options` <=> OLD.`required_options` OR NEW.`created_at` <=> OLD.`created_at`) THEN INSERT IGNORE INTO `scconnector_google_feed_cl` (`entity_id`) VALUES (NEW.`entity_id`); END IF;
IF (NEW.`entity_id` <=> OLD.`entity_id` OR NEW.`attribute_set_id` <=> OLD.`attribute_set_id` OR NEW.`type_id` <=> OLD.`type_id` OR NEW.`sku` <=> OLD.`sku` OR NEW.`has_options` <=> OLD.`has_options` OR NEW.`required_options` <=> OLD.`required_options` OR NEW.`created_at` <=> OLD.`created_at`) THEN INSERT IGNORE INTO `scconnector_google_remove_cl` (`entity_id`) VALUES (NEW.`entity_id`); END IF;
END;


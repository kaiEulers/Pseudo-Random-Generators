CREATE DEFINER = kai@localhost TRIGGER trg_catalog_product_entity_gallery_after_insert
    AFTER INSERT
    ON catalog_product_entity_gallery
    FOR EACH ROW
BEGIN
INSERT IGNORE INTO `scconnector_google_feed_cl` (`entity_id`) VALUES (NEW.`entity_id`);
END;


CREATE DEFINER = kai@localhost TRIGGER trg_cataloginventory_stock_item_after_delete
    AFTER DELETE
    ON cataloginventory_stock_item
    FOR EACH ROW
BEGIN
INSERT IGNORE INTO `scconnector_google_feed_cl` (`entity_id`) VALUES (OLD.`product_id`);
END;


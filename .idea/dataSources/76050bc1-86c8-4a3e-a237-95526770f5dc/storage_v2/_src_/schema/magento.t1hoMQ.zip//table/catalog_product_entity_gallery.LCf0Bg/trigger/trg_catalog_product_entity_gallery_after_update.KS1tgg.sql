CREATE DEFINER = kai@localhost TRIGGER trg_catalog_product_entity_gallery_after_update
    AFTER UPDATE
    ON catalog_product_entity_gallery
    FOR EACH ROW
BEGIN
IF (NEW.`value_id` <=> OLD.`value_id` OR NEW.`attribute_id` <=> OLD.`attribute_id` OR NEW.`store_id` <=> OLD.`store_id` OR NEW.`entity_id` <=> OLD.`entity_id` OR NEW.`position` <=> OLD.`position` OR NEW.`value` <=> OLD.`value`) THEN INSERT IGNORE INTO `scconnector_google_feed_cl` (`entity_id`) VALUES (NEW.`entity_id`); END IF;
END;


CREATE DEFINER = kai@localhost TRIGGER trg_catalog_product_website_after_update
    AFTER UPDATE
    ON catalog_product_website
    FOR EACH ROW
BEGIN
IF (NEW.`product_id` <=> OLD.`product_id` OR NEW.`website_id` <=> OLD.`website_id`) THEN INSERT IGNORE INTO `scconnector_google_remove_cl` (`entity_id`) VALUES (NEW.`product_id`); END IF;
END;


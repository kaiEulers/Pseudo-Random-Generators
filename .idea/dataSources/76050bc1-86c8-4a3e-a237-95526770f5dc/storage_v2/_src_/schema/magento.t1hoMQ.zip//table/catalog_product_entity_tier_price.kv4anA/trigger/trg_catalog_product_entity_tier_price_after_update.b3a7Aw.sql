CREATE DEFINER = kai@localhost TRIGGER trg_catalog_product_entity_tier_price_after_update
    AFTER UPDATE
    ON catalog_product_entity_tier_price
    FOR EACH ROW
BEGIN
IF (NEW.`value_id` <=> OLD.`value_id` OR NEW.`entity_id` <=> OLD.`entity_id` OR NEW.`all_groups` <=> OLD.`all_groups` OR NEW.`customer_group_id` <=> OLD.`customer_group_id` OR NEW.`qty` <=> OLD.`qty` OR NEW.`value` <=> OLD.`value` OR NEW.`website_id` <=> OLD.`website_id` OR NEW.`percentage_value` <=> OLD.`percentage_value`) THEN INSERT IGNORE INTO `scconnector_google_feed_cl` (`entity_id`) VALUES (NEW.`entity_id`); END IF;
END;


CREATE DEFINER = kai@localhost TRIGGER trg_catalog_product_entity_tier_price_after_delete
    AFTER DELETE
    ON catalog_product_entity_tier_price
    FOR EACH ROW
BEGIN
INSERT IGNORE INTO `scconnector_google_feed_cl` (`entity_id`) VALUES (OLD.`entity_id`);
END;


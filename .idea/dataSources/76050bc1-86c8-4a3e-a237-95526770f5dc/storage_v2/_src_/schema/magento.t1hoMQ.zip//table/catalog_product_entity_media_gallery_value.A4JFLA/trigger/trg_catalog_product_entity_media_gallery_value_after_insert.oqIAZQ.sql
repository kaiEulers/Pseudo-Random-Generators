CREATE DEFINER = kai@localhost TRIGGER trg_catalog_product_entity_media_gallery_value_after_insert
    AFTER INSERT
    ON catalog_product_entity_media_gallery_value
    FOR EACH ROW
BEGIN
INSERT IGNORE INTO `scconnector_google_feed_cl` (`entity_id`) VALUES (NEW.`entity_id`);
END;

